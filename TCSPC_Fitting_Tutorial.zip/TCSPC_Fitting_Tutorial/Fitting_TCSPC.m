%% Preparing time data and variable assignment
clear('numDataPoints'),numDataPoints=30000; %number of meaningful datapoints
    %to select out of 2^16
    %data points. This depends on the sync frequncy and also the detected
    %lifetime. Give it enough background tailing. The recommended value from
    %picoquant manual is 100 times more than the lifetime. 

clear('numDataTraces'), numDataTraces=5; %Number of recorded time traces 
    %usually the first one is
    %IRF of the measurement setup.

clear('timeSpan'),timeSpan = (0:65536-1)*0.032; %0.004 is the time resolution
    %and 65536 is the number of data point as the
    %aquisition board is 16bit (2^16 = 65536)
    %timeSpan=0:0.004:262.14;
clear ('tData'), tData(:,1) = timeSpan(1, 1:numDataPoints);
clear('timeSpan');

%if IRF time resolution is different then
%generate the tIRF variable differently

% clear ('yData'), yData = Counts(1:numDataPoints, 2:numDataTraces);
yData = Counts(1:numDataPoints, 2:numDataTraces+1);
yData(yData<1)=1; %this is necessary to be bigger than 0 so the the 
%weithing value doesn't becom infinity;
yData(isnan(yData))=1; %Correct if there is any NaN Values

semilogy(tData, yData)
xlim([5 1000])

% plot(tData, yData)
% xlim([2 50]) 

%End of preparing data for fitting algorithm

%% IRF simulation

clear ('tIrf'), tIrf = ((0:numDataPoints-1)*0.004)';

%Skip if you already assigned the variable
clear('yIrf'), yIrf = Counts(1:numDataPoints,1);
%yIrf = yIrf(1:62500,1);
% yIrf(yIrf<2)=2;
% yIrf=yIrf+2;
yIrf(isnan(yIrf))=0;

%prepare simulated IRF for deconvolution 
%do the fitting first before creating the 
%denoised (simulated) IRF data
semilogy(tIrf, yIrf)


%this pulseprofile consists of 4 guassian profile and exponential decay
%which can fit the pulse profile of solid state lasers from picoquant.
pulseProfile = @(x, tIrf) (...
    x(1)*exp(-((tIrf-x(2))/(1.41421*x(3))).^2) +...
    x(4)*exp(-((tIrf-x(5))/(1.41421*x(6))).^2) +...
    x(7)*exp(-((tIrf-x(8))/(1.41421*x(9))).^2) +...
    x(10)*exp(-((tIrf-x(11))/(1.41421*x(12))).^2) +...
    x(13)*exp(1/2 * (-2 * (tIrf-x(14)) + x(16)^2/x(15))/x(15)).*...
    erfc((x(16)^2/x(15) - (tIrf-x(14)))/(x(16) * sqrt(2)))+ ...
    x(17)); 

x0Irf = [30 12.2 0.028 ... first guassian prepuls a1 t01 w1 (1 2 3)
    300 12.23 0.026 ... second guassian main pulse a2 t02 w2 (4 5 6)
    15 12.33 0.05 ... third guassian main pulse a3 t03 w3 (7 8 9)
    12 12.5 0.09 ... fourth gaussian afterpulse a4 t04 w4 (10 11 12)
    10 12.3 0.15 0.12 ... tailing a5 t05 t5 w5 (13 14 15 16) 
    0.003]; %baseline 17
x0IrfLow = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];

%check the initial guess
% figH = figure();
plH = semilogy(tIrf, yIrf, tIrf, pulseProfile(x0Irf, tIrf));
axH = gca;
axH.XLim = [12 13];
axH.YLim = [1 350];

%check simulated for not having NaN values
%testIrf = pulseProfile(x0Irf, tIrf);

%guess
% figure;plot(tIrf, yIrf, tIrf, pulseProfile(xIrf, tIrf)) %check the intial
%guess

%--Fitting the pulse profile to experimental data 
%make sure the fitting stoped due to conversions not running out of
%evaluation limit
options = optimoptions('lsqcurvefit',...
    'FunctionTolerance', 1e-5,...
    'StepTolerance', 1e-7,...
    'OptimalityTolerance', 1e-5,...
    'MaxIterations', 1000,...
    'MaxFunctionEvaluations', 100000,...
    'UseParallel',false, 'display', 'iter' );
clear('xIrf'), xIrf = lsqcurvefit( @(x, tIrf) pulseProfile(x, tIrf), ...
    x0Irf,...
    tIrf, yIrf, x0IrfLow, [], options);
%--if it didn't converge just replace the intial guess and run the fitting
%again.
x0Irf = xIrf;

%to save computation time  the fitting can be
% done only around time zero not the full range
% tIrfmin=find(tIrf==3.2);
% tIrfmax = find(tIrf==4.1);

%check the fitted result
figH = figure();
plH = semilogy(tIrf, yIrf, tIrf, pulseProfile(xIrf, tIrf));
axH = gca;
axH.XLim = [12 13];
axH.YLim = [1 350];

%--Simulate the IRF
yIrfSim = pulseProfile(xIrf, tIrf); 
yIrfSim = yIrfSim - xIrf(17); %Removing the baseline 
yIrfSim(yIrfSim<0.3) = 0; %Threshholding the data so save computational time
sfigH = figure();  %double check the simulated data
plH = semilogy(tIrf, yIrf, tIrf, yIrfSim);
axH = gca;
axH.XLim = [12 14];
axH.YLim = [1 350];

%--Generate normal distribution of the smilulated the IRF
%ynIrf = yIrf/max(yIrf);
yIrfN=yIrfSim/trapz(tIrf, yIrfSim);
%yIrf(ynIrf<0.01)=0; %Threshholding this data is essential

%check the normal distribution form of IRF
% semilogy(tIrf, yIrfN)
% plot(tIrf, yIrfN)

%Clean up workspace
clear('x0Irf', 'x0IrfLow', 'plH', 'options', 'pulseProfile',...
    'sfigH', 'yIrf', 'axH', 'figH')

%The noiseless IRF is ready now proceed for the fitting algorithm

%% Estimating the initial guess, "x0", and choosing the model.

%  Double exponential
% x0 = (a1, t1, a2, t3, base, t0) for double exponential 
clear('x0'); x0 =  [1.9, 76, 8, 20, 0, 0, 0,  1.2, 12.1];
clear('xLow');xLow=[0 0 0 0 0 0];
xHigh=[];
semilogy(tData, yData(:, 1),tData, fit2expNumConv(x0, tData, tIrf, yIrfN));

%  Three Exponential
% fit3expNumConv x0 = (a1, t1, a2, t2, a3, t3, base, t0)
clear('x0'); x0 =  [6, 0.8, 133, 0.04, 5, 1, 00, 325, 10.52];
clear('xLow');xLow=[0 0 0 0 0 0 1 0];
xHigh=[];
semilogy(tData, yData(:, 1),tData, fit3expNumConv(x0, tData, tIrf, yIrfN));

%fit2expRisDecNumConv(x,tData, tIrf, yIrf)
%order of x (input parameters) array [a1, t1, a2, t2,  t_rd, base, t0]
%                                    [01, 02, 03, 04,  05,   06,   07]
clear('x0'); x0 =  [3, 18, 6, 8, 0, 0, 0.3, 1, 12.67];
clear('xLow');xLow=[0 0 0 0 0 0 0 1 0];
xHigh=[];
% Checking the initial guess
semilogy(tData, yData(:, 3),tData, fit2expRisDecNumConv(x0, tData, tIrf, yIrfN));

%fit3expRisDecNumConv(x,tData, tIrf, yIrf)
%order of x (input parameters) array [a1, t1, a2, t2, a3, t3, t_rd, base, t0]
%                                    [01, 02, 03, 04, 05, 06, 07,   08,   09]
clear('x0'); x0 =  [3, 18, 6, 8, 0.01, 3, 0.1, 1, 12.67];
clear('xLow');xLow=[0 0 0 0 0 0 0 1 0];
xHigh=[];
% Checking the initial guess
semilogy(tData, yData(:, 3),tData, fit3expRisDecNumConv(x0, tData, tIrf, yIrfN));




%% Costum list of intial guess Using Multistart
%determine the dataset number that data follows a differnt model
%make sure the numer of models matches the number of data traces
fitModelSel = string({'2Exp', '2Exp', '2Exp', '2Exp', '2Exp'});
    %, '2Exp','2Exp', '2Exp', '2Exp', '2Exp','2Exp', '2Exp'});
tic;
for i = 1: size(yData, 2)
    fitModelSw = fitModelSel(i);
    switch fitModelSw
        case '2ExpRD'
            disp('2 Exponential with Rise and Decay has been selected')
            x0=[];x0 =  [3, 18, 6, 8,0, 0, 0.3, 1, 12.67]; %Initila guess for 3 exponetial with rise and decay
            xLow = [];xLow = [0 0 0 0 0 0 0 1 0];
            xHigh=[];xHigh = [1000 1000 1000 1000 0 0 5 10 13];
            
            %generate costumized starting point for multistart

            pts=[]; ptsGen = @(a) 8*a .*rand(20,1) + a - 4*a;
            pts=[]; pts = ptsGen(x0);
            tpoints=[]; tpoints = CustomStartPointSet(pts);
            rpts=[]; rpts = RandomStartPointSet('NumStartPoints',40);
            allpts=[]; allpts = {tpoints,rpts};
            
            % dataSet=i; %determine which data set (column number) to fit from data array
            %     decModel = @(x, tData, tIrf, yIrfN)fit3expRisDecNumConv(x, tData, tIrf, yIrfN);
            decModel = @(x, tData, tIrf, yIrfN)fit2expRisDecNumConv(x, tData, tIrf, yIrfN);
            %     decModel = @(x, tData, tIrf, yIrfN)fit2expNumConv(x, tData, tIrf, yIrfN);
            %     decModel = @(x, tData, tIrf, yIrfN)fit3expNumConv(x, tData, tIrf, yIrfN);
            % minProblem=@(x)sum(1./yData(:,dataSet).*(decModel(x, tData, tIrf, yIrfN)-yData(:,dataSet)).^2);
            minProblem = @(x)sum(1./yData(:,i).*(decModel(x, tData, tIrf, yIrfN)-yData(:,i)).^2);
            
            %rng(40,'twister') % for reproducibility
            rng default % For reproducibility
            opts = optimoptions(@fmincon,...
                'FunctionTolerance', 1e-7,...
                'StepTolerance', 1e-7,...
                'OptimalityTolerance', 1e-7,...
                'MaxIterations', 500,...
                'MaxFunctionEvaluations', 3000);
            problem = createOptimProblem('fmincon','objective',...
                minProblem,'x0',x0,'lb',xLow ,'ub',xHigh, 'options', opts);
            ms = MultiStart( 'UseParallel', 1, 'Display', 'iter');
            x = run(ms,problem,allpts);
            
            yDataSim(:,i) = decModel(x, tData, tIrf, yIrfN);
            xFit(i,:) = x;
        case '2Exp'
            disp('2 Exponential has been selected')
            x0=[];x0 =  [1.9, 76, 8, 20, 0, 0, 0,  1.2, 12.1]; %Initila guess for the selected model
            xLow = []; xLow = [0 0 0 0 0 0 0 1 0];
            xHigh=[]; xHigh = [1000 1000 1000 1000 0 0 0 1000 13];
            
            %generate costumized starting point for multistart
            pts=[]; ptsGen = @(a) 8*a .*rand(20,1) + a - 4*a;
            pts=[]; pts = ptsGen(x0);
            tpoints=[]; tpoints = CustomStartPointSet(pts);
            rpts=[]; rpts = RandomStartPointSet('NumStartPoints',40);
            allpts=[]; allpts = {tpoints,rpts};
            
                % dataSet=i; %determine which data set (column number) to fit from data array
                % decModel = @(x, tData, tIrf, yIrfN)fit3expRisDecNumConv(x, tData, tIrf, yIrfN);
                % decModel = @(x, tData, tIrf, yIrfN)fit2expRisDecNumConv(x, tData, tIrf, yIrfN);
                decModel = @(x, tData, tIrf, yIrfN)fit2expNumConv(x, tData, tIrf, yIrfN);
                % decModel = @(x, tData, tIrf, yIrfN)fit3expNumConv(x, tData, tIrf, yIrfN);
                % minProblem=@(x)sum(1./yData(:,dataSet).*(decModel(x, tData, tIrf, yIrfN)-yData(:,dataSet)).^2);
            minProblem = @(x)sum(1./yData(:,i).*(decModel(x, tData, tIrf, yIrfN)-yData(:,i)).^2);
            
            %rng(40,'twister') % for reproducibility
            rng default % For reproducibility
            opts = optimoptions(@fmincon,...
                'FunctionTolerance', 1e-7,...
                'StepTolerance', 1e-7,...
                'OptimalityTolerance', 1e-7,...
                'MaxIterations', 500,...
                'MaxFunctionEvaluations', 3000);
            problem = createOptimProblem('fmincon','objective',...
                minProblem,'x0',x0,'lb',xLow ,'ub',xHigh, 'options', opts);
            ms = MultiStart( 'UseParallel', 1, 'Display', 'iter');
            x = run(ms,problem,allpts);
            
            yDataSim(:,i) = decModel(x, tData, tIrf, yIrfN);
            xFit(i,:) = x;
        case '3Exp'
            disp('3 Exponential has been selected')
            x0=[];x0 =  [8, 0.8, 100,0.1,5, 1, 0,  300, 10.5]; %Initila guess for the selected model
            xLow = []; xLow = [0 0 0 0 0 0 0 1 0];
            xHigh=[]; xHigh = [1000 1000 1000 1000 1000 1000 0 1000 13];
            
            %generate costumized starting point for multistart
            pts=[]; ptsGen = @(a) 8*a .*rand(20,1) + a - 4*a;
            pts=[]; pts = ptsGen(x0);
            tpoints=[]; tpoints = CustomStartPointSet(pts);
            rpts=[]; rpts = RandomStartPointSet('NumStartPoints',40);
            allpts=[]; allpts = {tpoints,rpts};
            
            % dataSet=i; %determine which data set (column number) to fit from data array
            % decModel = @(x, tData, tIrf, yIrfN)fit3expRisDecNumConv(x, tData, tIrf, yIrfN);
            % decModel = @(x, tData, tIrf, yIrfN)fit2expRisDecNumConv(x, tData, tIrf, yIrfN);
            %decModel = @(x, tData, tIrf, yIrfN)fit2expNumConv(x, tData, tIrf, yIrfN);
            decModel = @(x, tData, tIrf, yIrfN)fit3expNumConv(x, tData, tIrf, yIrfN);
            % minProblem=@(x)sum(1./yData(:,dataSet).*(decModel(x, tData, tIrf, yIrfN)-yData(:,dataSet)).^2);
            minProblem = @(x)sum(1./yData(:,i).*(decModel(x, tData, tIrf, yIrfN)-yData(:,i)).^2);
            
            %rng(40,'twister') % for reproducibility
            rng default % For reproducibility
            opts = optimoptions(@fmincon,...
                'FunctionTolerance', 1e-7,...
                'StepTolerance', 1e-7,...
                'OptimalityTolerance', 1e-7,...
                'MaxIterations', 500,...
                'MaxFunctionEvaluations', 3000);
            problem = createOptimProblem('fmincon','objective',...
                minProblem,'x0',x0,'lb',xLow ,'ub',xHigh, 'options', opts);
            ms = MultiStart( 'UseParallel', 1, 'Display', 'iter');
            x = run(ms,problem,allpts);
            
            yDataSim(:,i) = decModel(x, tData, tIrf, yIrfN);
            xFit(i,:) = x;
    end 
end
tElapsed=toc;
disp(datestr(datenum(0,0,0,0,0,tElapsed), 'dd HH:MM:SS'))
% clean the workspace


%--Checking fitted data
%axes('ColorOrder',vega10(10),'NextPlot','replacechildren') 
h1 = semilogy(tData,yData);
for i = 1:size(h1,1) 
    h1(i).Color(4) = 0.3;
    h1(i).LineWidth = 0.1;
end
xlim ([10 500]);
ylim ([1 400])
xlim manual
hold on
set(gca, 'ColorOrderIndex', 1);
semilogy(tData,yDataSim, '-', 'linewidth',2.5)
% [plH patH] = boundedline(tData, yDataSim4(:,5), yDataDelta)
hold off

 xFit(xFit<1e-6)=0;

clear('allpts', 'ans', 'decModel', 'fitModelSw', 'i', ...
    'minProblem', 'ms', 'opts', 'problem', 'pts', 'ptsGen', 'rpts', ...
    'tElapsed', 'tpoints', 'x','x0', 'xLow', 'xHigh', 'h1')



 %% Calculating the confidence interval for fitted parameter and simulated curve
for i = 1: size(yData, 2)
     % fitModelSw = fitModelSel(i);
    switch fitModelSel(i)
        case '2ExpRD'
            disp('2 Exponential with Rise and Decay has been selected')
            xLow = [];xLow =  xFit(i,:);
            xHigh=[];xHigh =  xFit(i,:);
%             lsqnonlinFun =  @(x)(1./sqrt(yData(:,i)).*(fit2expRisDecNumConv(x, tData, tIrf, yIrfN)-yData(:,i)));
            decModelFun = @(x,tData)fit2expRisDecNumConv(x, tData, tIrf, yIrfN);
            statOpt = statset('Display', 'iter', 'MaxIter', 1000,...
                'TolX', 1e-40,'TolFun', 1e-40);
            [x2,x2Res,~,x2CovB,x2MSE,~] = nlinfit(tData,yData(:,i),...
                decModelFun,xFit(i,:),statOpt );
%             [x2,x2sse,x2Res,~,~,~,x2Jac]=...
%                 lsqnonlin(lsqnonlinFun, xFit(i,:), xLow, xHigh); %nlinfit is just from
            % statistical toolbox as nlparci and nlpredci
            
            confInt1 = nlparci(x2, x2Res, 'covar',x2CovB);
            confInt2 = (confInt1(:,2) - confInt1(:,1))/2;
%             [yPred, yDelta] = nlpredci(decModelFun,tData, x2, x2Res,...
%                 'jacobian', x2Jac);
            [yPred, yDelta] = nlpredci(decModelFun,tData,...
                x2, x2Res,'Covar',x2CovB,...
                'MSE',x2MSE,'SimOpt','on');
            
            fitR2(i) = 1 - norm(yData(:,i)-yDataSim(:,i))/norm(yData(:,i));
            xFitCI(i,:) = confInt2;
            yDataDelta(:,i) = yDelta;
            yDataLower(:,i) = yPred - yDelta; %creates the lower and
            yDataUpper(:,i) = yPred - yDelta;
    
        case '2Exp'
            disp('2 Exponential has been selected')
            xLow = [];xLow = xFit(i,:);
            xHigh=[];xHigh = xFit(i,:);
            % lsqnonlinFun =  @(x)(1./sqrt(yData(:,i)).*(decModel(x, tData, tIrf, yIrfN)-yData(:,i)));
            decModelFun = @(x,tData)fit2expNumConv(x, tData, tIrf, yIrfN);
            statOpt = statset('Display', 'iter', 'MaxIter', 1000,...
                'TolX', 1e-40,'TolFun', 1e-40);
            [x2,x2Res,~,x2CovB,x2MSE,~] = nlinfit(tData,yData(:,i),...
                decModelFun,xFit(i,:),statOpt );
            % [x2,x2sse,x2Res,~,~,~,x2Jac]=...
            % lsqnonlin(lsqnonlinFun, xFit(i,:)); %nlinfit is just from
            % statistical toolbox as nlparci and nlpredci
            
            confInt1 = nlparci(x2, x2Res, 'covar',x2CovB);
            confInt2 = (confInt1(:,2) - confInt1(:,1))/2;
            % [yPred, yDelta] = nlpredci(decModelFun,tData, x2, x2Res,...
            %     'jacobian', x2Jac);
            [yPred, yDelta] = nlpredci(decModelFun,tData,...
                x2, x2Res,'Covar',x2CovB,...
                'MSE',x2MSE,'SimOpt','on');
            
            fitR2(i) = 1 - norm(yData(:,i)-yDataSim(:,i))/norm(yData(:,i));
            xFitCI(i,:) = confInt2;
            yDataDelta(:,i) = yDelta;
            yDataLower(:,i) = yPred - yDelta; %creates the lower and
            yDataUpper(:,i) = yPred - yDelta;
        case '3Exp'
            disp('3 Exponential has been selected')
            xLow = [];xLow = xFit(i,:);
            xHigh=[];xHigh = xFit(i,:);
            % lsqnonlinFun =  @(x)(1./sqrt(yData(:,i)).*(decModel(x, tData, tIrf, yIrfN)-yData(:,i)));
            decModelFun = @(x,tData)fit3expNumConv(x, tData, tIrf, yIrfN);
            statOpt = statset('Display', 'iter', 'MaxIter', 1000,...
                'TolX', 1e-40,'TolFun', 1e-40);
            [x2,x2Res,~,x2CovB,x2MSE,~] = nlinfit(tData,yData(:,i),...
                decModelFun,xFit(i,:),statOpt );
            % [x2,x2sse,x2Res,~,~,~,x2Jac]=...
            % lsqnonlin(lsqnonlinFun, xFit(i,:)); %nlinfit is just from
            % statistical toolbox as nlparci and nlpredci
            
            confInt1 = nlparci(x2, x2Res, 'covar',x2CovB);
            confInt2 = (confInt1(:,2) - confInt1(:,1))/2;
            % [yPred, yDelta] = nlpredci(decModelFun,tData, x2, x2Res,...
            %     'jacobian', x2Jac);
            [yPred, yDelta] = nlpredci(decModelFun,tData,...
                x2, x2Res,'Covar',x2CovB,...
                'MSE',x2MSE,'SimOpt','on');
            
            fitR2(i) = 1 - norm(yData(:,i)-yDataSim(:,i))/norm(yData(:,i));
            xFitCI(i,:) = confInt2;
            yDataDelta(:,i) = yDelta;
            yDataLower(:,i) = yPred - yDelta; %creates the lower and
            yDataUpper(:,i) = yPred - yDelta;
    end
        
end

xFitCI(xFitCI<1e-6)=0;

clear ('ans', 'confInt1', 'confInt2', 'decModelFun', 'i', 'lsqnonlinFun', ...
    'statOpt', 'x2', 'x2CovB', 'x2MSE', 'x2Res', 'yPred', 'yDelta', 'xLow', 'xHigh')


%% Post processing data, scalling and normalization
%For removing the offset you can use the xFit(:,end-1) too instead of the
%first element of fitted data
yDataN = bsxfun(@minus, yData, yDataSim(1,:)); %Remove the offset
%normalize to fitted and scale the data
yDataN = bsxfun(@rdivide, yDataN, (max(yDataSim)-yDataSim(1,:)));
%normalize and scale the fitted data
yDataSimN = bsxfun(@minus, yDataSim, yDataSim(1,:)); %Remove the offset
yDataSimN = bsxfun(@rdivide, yDataSimN, max(yDataSimN)); 
%Normalize yDataDelta (Confidence interval prediction delta)
yDataDeltaN = bsxfun(@rdivide, yDataDelta, (max(yDataSim)-yDataSim(1,:)));

%correct time zero
% tDataMod = tData - mean (xFit(:,end));
for i=1:size(xFit,1)
    tDataMod(:,i) = tData - xFit(i, end);
end

%% -- Case of 2 Exponentials 
% Normalized Amplitude
xFitMod = [xFit(:,1:4),xFit(:,end-2:end)];% Removing zeros if the model 
xFitCIMod = [xFitCI(:,1:4),xFitCI(:,end-2)];
% Double exponential Rise and decay
for i = 1:size(xFitMod, 1) % Amplitude Normalization for 2 exponential model 
    ampSum = (xFitMod(i,1) + xFitMod(i,3));
    xFitMod(i, 1) = xFitMod(i, 1)/ampSum;
    xFitMod(i, 3) = xFitMod(i, 3)/ampSum;
    xFitCIMod(i, 1) = xFitCIMod(i, 1)/ampSum;
    xFitCIMod(i, 3) = xFitCIMod(i, 3)/ampSum;
end

%Average lifetime for 2 exponential
avglifetime=(xFit(:,1).*xFit(:,2).^2+xFit(:,3).*xFit(:,4).^2)./...
    (xFit(:,1).*xFit(:,2)+xFit(:,3).*xFit(:,4));

clear('ampSum', 'i')

%% -- Case of 3 Exponentials 
% Normalized Amplitude
xFitMod = [xFit(:,1:6),xFit(:,end-1:end)]; % Removing zeros if the model 

for i = 1:size(xFitMod, 1) % Amplitude Normalization for 2 exponential model 
    ampSum = (xFitMod(i,1) + xFitMod(i,3)+xFitMod(i,5));
    xFitMod(i, 1) = xFitMod(i, 1)/ampSum;
    xFitMod(i, 3) = xFitMod(i, 3)/ampSum;
    xFitMod(i, 5) = xFitMod(i, 5)/ampSum;
end

%Average lifetime for three exponential
avglifetime=(xFit(:,1).*xFit(:,2).^2 + xFit(:,3).*xFit(:,4).^2 + xFit(:,5).*xFit(:,6).^2) ./...
    (xFit(:,1).*xFit(:,2) + xFit(:,3).*xFit(:,4) + xFit(:,5).*xFit(:,6));

clear('ampSum', 'i')

%% Ploting 
figH = figure();
axes('ColorOrder',vega10(10),'NextPlot','replacechildren') 
plH1 = plot(tDataMod,yDataN);
axH = gca;
box on
hold on
set(gca, 'ColorOrderIndex', 1);
plH2 = plot(tDataMod,yDataSimN);
%[plH2, patH2] = boundedline(tData, yDataSimN(:,5), yDataDeltaN(:,5));
hold off

% plH.EdgeColor = 'none';
for i = 1:size(plH1,1) 
    plH1(i).Color(4) = 0.4;
    plH1(i).LineWidth = 0.2;
end

% plH.EdgeColor = 'none';
for i = 1:size(plH2,1) 
    plH2(i).LineWidth = 2;
end


figH.Color = 'w';
figH.PaperPositionMode = 'manual';
% figH.PaperUnits = 'inches';
figH.Units = 'Pixels';%'inches';
% figH.PaperPosition = [0, 0, 5, 3.09];
% figH.PaperSize = [5, 3.09];
figH.Position = [300 100 500 385]; %[0.1, 0.1, 4.9, 2.99];
figH.Resize = 'off';
figH.InvertHardcopy = 'off';


axH.Color = 'none';
% axH.YScale = 'log';
axH.XLim = [-2 50];
axH.YLim = [0.01 1.2];
% axH.ZLim = [1.2 9.5];
axH.FontSize = 12;
axH.LineWidth = 1.5;
% axH.XTick = 550:50:850;
% axH.YTick = ;
% axH.TickLabelInterpreter = 'LaTeX';
% axH.FontName = 'LaTeX';
% axH.Title.Interpreter = 'LaTeX';
% axH.XLabel.Interpreter = 'LaTeX';
% axH.YLabel.Interpreter = 'LaTeX';
axH.XLabel.String = 'Time (ns)';
axH.YLabel.String = 'PL (a.u.)';
% axH.XMinorTick = 'on';
% axH.YMinorTick = 'on';
% axH.Mode = 'image'
% axH.Style = 'tight'
axH.LooseInset = axH.TightInset;

legVal = {'790'; '730'; '680'; '640'; '580'};
legH = legend(plH2,legVal);
legH.Color = 'none';
% legH.Interpreter = 'LaTeX';
legH.Location = 'Best';
legH.Orientation = 'Vertical'; %'Vertical'


% t = title('US Flu Infection Rates from Oct. 2005 -- Oct 2006');
% t.Color = 'white';
% t.Interpreter = 'LaTeX';

% print('-painters','-clipboard','-dmeta')

%subplot and costume position combined with hididng the axis can be used to
%merge plots 


%% Clean Workspace for the final output
clear('ampSum', 'axH', 'figH', 'i', 'legH', 'legVal', 'patH', 'plH1', ...
    'plH2')



%%

%% Fitting using global search in case it's needed for rough estimation
tic;
parfor i = 1: size(yData, 2)
% dataSet=i; %determine which data set (column number) to fit from data array
decModel = @(x, tData, tIrf, yIrfN)fit3expRisDecNumConv(x, tData, tIrf, yIrfN);
% minProblem=@(x)sum(1./yData(:,dataSet).*(decModel(x, tData, tIrf, yIrfN)-yData(:,dataSet)).^2);
minProblem = @(x)sum(1./yData(:,i).*(decModel(x, tData, tIrf, yIrfN)-yData(:,i)).^2);

rng(40,'twister') % for reproducibility
rng default % For reproducibility
opts = optimoptions(@fmincon,'Algorithm','active-set',...
    'FunctionTolerance', 1e-9,...
    'StepTolerance', 1e-8,...
    'OptimalityTolerance', 1e-8,...
    'MaxIterations', 1000,...
    'MaxFunctionEvaluations', 10000);
problem = createOptimProblem('fmincon','objective',...
    minProblem,'x0',x01(i,:),'lb',xLow ,'ub',xHigh, 'options', opts);
% ms = MultiStart( 'UseParallel', 1);
% x = run(ms,problem,10);
gs = GlobalSearch('Display','iter',...
    'NumTrialPoints', 2000,...
    'NumStageOnePoints', 1000);
x = run(gs, problem);

yDataSim3(:,i) = decModel(x, tData, tIrf, yIrfN);
xFit3(i,:) = x;
end
tElapsed=toc;
disp(datestr(datenum(0,0,0,0,0,tElapsed), 'dd HH:MM:SS'))


%--Checking fitted data
axes('ColorOrder',vega10(10),'NextPlot','replacechildren') 
semilogy(tData,yData, '.', 'linewidth', 0.1)
alpha(0.2)
xlim ([2 200]);
ylim ([1 400])
xlim manual
hold on
set(gca, 'ColorOrderIndex', 1);
semilogy(tData,yDataSim, '-', 'linewidth',2.5)
% [plH patH] = boundedline(tData, yDataSim4(:,5), yDataDelta)
hold off

%--Checking fitted data
figure;plot(tData,yData(:,dataSet), '.')
xlim ([2 1000]);
xlim manual
hold on
set(gca, 'ColorOrderIndex', 1);
plot(tData,yDataSim(:,dataSet), '-', 'linewidth',2.5)
hold off

