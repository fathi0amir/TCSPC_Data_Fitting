function expDecConv=fit2expRisDecNumConv(x,tData, tIrf, yIrf)
%order of x (input parameters) array [a1, t1, a2, t2, 00, 00, t_rd, base, t0]
%                                    [01, 02, 03, 04, 05, 06, 07,   08,   09]
% Zeros are reserved for other models
a1=x(1,1);
k1=1/x(1,2);
a2=x(1,3);
k2=1/x(1,4);
k_rd= 1/x(1,end-2);
base=x(1,end-1);
t0= x(1,end);



[~, maxInd]=max(yIrf);
tDummy=tIrf(maxInd,1 );
tIrf=tIrf-tDummy+t0;
yIrfInterp=interp1(tIrf, yIrf, tData); 
yIrfInterp(isnan(yIrfInterp))=0;
%yIrfInterp=yIrfInterp/max(yIrfInterp);

expDec=a1*(k_rd/(k_rd-k1)*(exp(-k1*tData)-exp(-k_rd*tData)))...
    + a2*(k_rd/(k_rd-k2)*(exp(-k2*tData)-exp(-k_rd*tData)));

expDecConv=conv(expDec, yIrfInterp);
%expDecConv=expDecConv/max(expDecConv);%normalize
expDecConv(isnan(expDecConv))=0;
expDecConv=expDecConv(1:end-size(yIrfInterp,1)+1) + base;
end