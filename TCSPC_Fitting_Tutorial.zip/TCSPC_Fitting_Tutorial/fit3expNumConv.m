function expDecConv=fit3expNumConv(x,tData, tIrf, yIrf)
%order of x (input parameters) array [a1, t1, a2, t2, a3, t3, 00, base, t0]
%                                    [01, 02, 03, 04, 05, 06, 07, 08  , 09]
a1=x(1,1);
k1=1/x(1,2);
a2=x(1,3);
k2=1/x(1,4);
a3 = x(1, 5);
k3 = 1/x(1, 6);
base=x(1,8);
t0= x(1,9);


[~, maxInd]=max(yIrf);
tDummy=tIrf(maxInd,1 );
tIrf=tIrf-tDummy+t0;
yIrfInterp=interp1(tIrf, yIrf, tData); 
yIrfInterp(isnan(yIrfInterp))=0;
%yIrfInterp=yIrfInterp/max(yIrfInterp);

expDec=...
    a1*exp(-k1*(tData-min(tData))) + ...
    a2*exp(-k2*(tData-min(tData))) + ...
    a3*exp(-k3*(tData-min(tData)));
%expDec(expDec<base)=base;

expDecConv=conv(expDec, yIrfInterp);
%expDecConv=expDecConv/max(expDecConv);%normalize
%expDecConv(isnan(expDecConv))=0;
expDecConv=expDecConv(1:end-size(yIrfInterp,1)+1)+base;
end